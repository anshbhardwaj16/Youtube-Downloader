from pytube import YouTube
def download(link):
  videoObj=YouTube(link)
  videoObj=videoObj.streams.get_highest_resolution()
  try:
    videoObj.download()
  except:
    print("Error!!!")
  print("Video Downloaded!!Hurray!!")
link=input("Enter the URl: ")
download(link)




  

